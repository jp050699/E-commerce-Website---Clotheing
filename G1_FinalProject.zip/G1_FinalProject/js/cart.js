$(document).ready(function() {
    // Add to cart functionality
    $(".add-to-cart-btn").click(function() {
        const button = $(this);
        const productName = $(this).data("name");
        const productPrice = $(this).data("price");
        const productImage = $(this).closest(".property-card").find("img").attr("src");

        button.text("Added").prop("disabled", true);

        // Create new cart item element
        const cartItem = $(`
            <li>
                <img src="${productImage}" alt="${productName}" class="cart-item-image">
                <div class="cart-item-details">
                    <span class="cart-item-name">${productName}</span>
                    <span class="cart-item-price">$${productPrice.toFixed(2)}</span>
                    <div class="cart-quantity">
                        <button class="quantity-btn decrement">-</button>
                        <span class="quantity">1</span>
                        <button class="quantity-btn increment">+</button>
                    </div>
                </div>
            </li>
        `);
        $("#cart-items").append(cartItem);

        // Update total
        updateTotal();
    });

    // Increment and Decrement quantity buttons
    $("#cart-items").on("click", ".increment", function() {
        const quantityElement = $(this).siblings(".quantity");
        let quantity = parseInt(quantityElement.text());
        quantity++;
        quantityElement.text(quantity);
        updateTotal();
    });

    $("#cart-items").on("click", ".decrement", function() {
        const quantityElement = $(this).siblings(".quantity");
        let quantity = parseInt(quantityElement.text());
        if (quantity > 1) {
            quantity--;
            quantityElement.text(quantity);
            updateTotal();
        }
    });

    // Show cart sidebar when cart icon is clicked
    $(".fa-shopping-cart").click(function() {
        $("#cart-sidebar").css("width", "300px");
    });

    // Hide cart sidebar when close button is clicked
    $(".close-sidebar").click(function() {
        $("#cart-sidebar").css("width", "0");
    });

    // Proceed to checkout
    $("#checkout-btn").click(function() {
        // Redirect to checkout page
        window.location.href = "checkout.html";
    });

    $("#cart-items").on("click", ".delete-btn", function() {
        $(this).closest("li").remove();
        updateTotal();
    });

    // Function to update total
    function updateTotal() {
        let total = 0;
        $("#cart-items li").each(function() {
            const price = parseFloat($(this).find(".cart-item-price").text().replace("$", ""));
            const quantity = parseInt($(this).find(".quantity").text());
            total += price * quantity;
        });
        $("#cart-total").text(total.toFixed(2));
    }

    $("#cart-items").on("click", ".decrement", function() {
        const quantityElement = $(this).siblings(".quantity");
        let quantity = parseInt(quantityElement.text());
        if (quantity > 1) {
            quantity--;
            quantityElement.text(quantity);
            updateTotal();
        } else {
            // Remove product from cart if quantity is 0
            $(this).closest("li").remove();
            updateTotal();
        }
    });
   
});
