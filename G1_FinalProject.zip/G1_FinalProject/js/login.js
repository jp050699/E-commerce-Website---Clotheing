"use strict";
document
  .getElementById("loginForm")
  .addEventListener("submit", function (event) {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var errorMessage = document.getElementById("errorMessage");

    if (!username || !password) {
      errorMessage.innerText = "Username and password are required";
      event.preventDefault();
      return;
    }

    var validUsername = "group1";
    var validPassword = "group@123";

    if (username !== validUsername) {
      errorMessage.innerText = "Username is not correct";
      event.preventDefault();
      return;
    }

    if (password !== validPassword) {
      errorMessage.innerText = "Password is not Correct";
      event.preventDefault();
      return;
    }

    alert("Login successful!");

  });
