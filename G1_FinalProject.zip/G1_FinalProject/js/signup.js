document
  .getElementById("registrationForm")
  .addEventListener("submit", function (event) {
    var firstName = document.getElementById("firstName").value;
    var lastName = document.getElementById("lastName").value;
    var email = document.getElementById("email").value;
    var mobileNumber = document.getElementById("mobileNumber").value;
    var address = document.getElementById("address").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;

    // It validates that customer can not redirect without filling this form
    if (
      !firstName ||
      !lastName ||
      !email ||
      !mobileNumber ||
      !address ||
      !password ||
      !confirmPassword
    ) {
      alert("All fields are required");
      event.preventDefault();
      return;
    }

    // user cannot add numbers
    if (!isNaN(firstName)) {
      alert("First Name cannot contain numbers");
      event.preventDefault();
      return;
    }

    // user cannot add numbers
    if (!isNaN(lastName)) {
      alert("Last Name cannot contain numbers");
      event.preventDefault();
      return;
    }

    // without @ email address is not valid
    if (!email.includes("@")) {
      alert("Email must contain @ symbol");
      event.preventDefault();
      return;
    }

    // mobile number is not accepted if your number is more or less
    if (!/^\d{10}$/.test(mobileNumber)) {
      alert("Mobile number must be 10 digits");
      event.preventDefault();
      return;
    }

    if (
      !/(?=.*[a-zA-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{6,}/.test(
        password
      )
    ) {
      alert(
        "Password must contain at least one letter, one number, and one special character, and be at least 6 characters long"
      );
      event.preventDefault();
      return;
    }

    if (password.length < 6) {
      alert("Password must be at least 6 characters long");
      event.preventDefault();
      return;
    }

    // users password must be same
    if (password !== confirmPassword) {
      alert("Passwords do not match");
      event.preventDefault();
      return;
    }

    alert("Registration successful!");
  });

// when user hover mouse on a home page images it can pop up
$(document).ready(function () {
  $(".property img").hover(
    function () {
      $(this).css("opacity", "0.8");
    },
    function () {
      $(this).css("opacity", "1");
    }
  );
});
