/* handle the scrolling behavior */
document.addEventListener("DOMContentLoaded", function () {
    const navbar = document.querySelector(".navbar");
    const main = document.querySelector("main");

    window.addEventListener("scroll", function () {
        if (window.scrollY > navbar.offsetHeight) {
            navbar.classList.add("fixed");
            main.style.paddingTop = navbar.offsetHeight + "px";
        } else {
            navbar.classList.remove("fixed");
            main.style.paddingTop = "0";
        }
    });
});
