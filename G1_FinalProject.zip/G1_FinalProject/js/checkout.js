document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');

    form.addEventListener('submit', function(event) {
        event.preventDefault();

        // Perform form validation
        if (validateForm()) {
            // If form is valid, display success message and redirect
            alert('Payment successful!');
            window.location.href = '../index.html'; // Adjust the path if necessary
        }
    });

    function validateForm() {
        return true;
    }
});
